from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
# request---> response
# request handler
def home(request):   
    return render(request,'users/index.html') 

def book(request):   
    return render(request,'users/book.html') 
    
